/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "4acc87427d7a24c270177b29fab21d5e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "baa7aaeb72e28979544d4b048e4d3d1b"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b70e8b86721ef4f4ac008f13d5fea10e"
  }, {
    "url": "manifest.json",
    "revision": "96f39f9c34975ba371bf0e512ba22881"
  }, {
    "url": "index.html",
    "revision": "1b09e55ff9e8f67de57b034581576d9b"
  }, {
    "url": "icon.svg",
    "revision": "c5e6b0938662967e2caa5b34b8859019"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "37f272dbd4b6fad5799ddf5b14ae5b71"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-TKGC8ZEE.js",
    "revision": null
  }, {
    "url": "assets/index-CKFrLz4I.css",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "37f272dbd4b6fad5799ddf5b14ae5b71"
  }, {
    "url": "icon.svg",
    "revision": "c5e6b0938662967e2caa5b34b8859019"
  }, {
    "url": "manifest.json",
    "revision": "96f39f9c34975ba371bf0e512ba22881"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b70e8b86721ef4f4ac008f13d5fea10e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "baa7aaeb72e28979544d4b048e4d3d1b"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "4acc87427d7a24c270177b29fab21d5e"
  }, {
    "url": "manifest.webmanifest",
    "revision": "70c80d5e19b65936ca1d983fd9474dbd"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html")));
  workbox.registerRoute(/^https:\/\/everyayah\.com\/data\/.*/i, new workbox.CacheFirst({
    "cacheName": "quran-audio-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 100,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 20,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 30,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
